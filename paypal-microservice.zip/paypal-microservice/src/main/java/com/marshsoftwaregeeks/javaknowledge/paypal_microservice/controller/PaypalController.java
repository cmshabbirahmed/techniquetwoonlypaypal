package com.marshsoftwaregeeks.javaknowledge.paypal_microservice.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;
import com.marshsoftwaregeeks.javaknowledge.paypal_microservice.model.PaypalDTO;
import com.marshsoftwaregeeks.javaknowledge.paypal_microservice.service.PaypalService;
import com.paypal.api.payments.Links;
import com.paypal.api.payments.Payment;
import com.paypal.base.rest.PayPalRESTException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class PaypalController {

    @Autowired
    private PaypalService paypalService;

    @Value("${app.cancel.url}")
    private String cancelUrl;

    @Value("${app.success.url}")
    private String successUrl;

    @GetMapping("/")
    public String home () {
        return "index";
    }

    @PostMapping("pay")
    public RedirectView sendPayment(@RequestParam("method") String method,
                                     @RequestParam("amount") String amount,
                                     @RequestParam("currency") String currency,
                                     @RequestParam("description") String description){
        try {
            PaypalDTO payload = PaypalDTO.builder()
                    .total(Double.valueOf(amount))
                    .method(method)
                    .currency(currency)
                    .description(description)
                    .cancelUrl(cancelUrl)
                    .successUrl(successUrl)
                    .intent("sale")
                    .build();
            Payment payment = paypalService.createPayment(payload);
            Links link = payment.getLinks().stream()
                    .filter(l -> l.getRel().equals("approval_url"))
                    .findFirst()
                    .orElse(null);
            if(link != null) {
                return new RedirectView(link.getHref());
            }
        }catch (Exception e) {
            log.error("Payment Failed: " + e.getMessage());
        }
        return new RedirectView("error");
    }

@ResponseBody
@PostMapping("execute")
public ResponseEntity<?> executePayment(@RequestParam("paymentId") String paymentId,
    @RequestParam("PayerID") String payerId) {
    try {
        Payment payment = paypalService.executePayment(paymentId, payerId);
        if (payment.getState().equals("approved")) {
            return ResponseEntity.status(HttpStatus.CREATED).body(String.format("Payment Sent Successfully: %s Payer : %s", payment.getId()));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(String.format("Payment Failed while processing: %s Payer : %s", payment.getId()));
    } catch (Exception e) {
        log.error(e.getMessage());
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(String.format("Payment failed: %s", e.getMessage()));
    }
}

    @GetMapping("success")
    public String paymentSuccess(
            @RequestParam("paymentId") String paymentId,
            @RequestParam("PayerID") String payerId
    ) {
        try {
            Payment payment = paypalService.executePayment(paymentId, payerId);
            if (payment.getState().equals("approved")) {
                return "success";
            }
        } catch (PayPalRESTException e) {
            log.error("Error occurred:: ", e);
        }
        return "error";
    }

    @GetMapping("cancel")
    public String paymentCancel() {
        return "cancel";
    }
    @GetMapping("error")
    public String paymentError() {
        return "error";
    }
}
