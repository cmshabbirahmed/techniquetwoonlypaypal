package com.marshsoftwaregeeks.javaknowledge.paypal_microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaypalMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaypalMicroserviceApplication.class, args);
	}

}
