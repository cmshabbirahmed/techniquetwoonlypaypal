package com.marshsoftwaregeeks.javaknowledge.paypal_microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaypalMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
